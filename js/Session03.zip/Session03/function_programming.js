
//? Functional Programming

const addTen = num => num + 10;

const double = num => num * 2;

//! Function Composition
const addTenAdnDouble = num => double(addTen(num))

const inputNumber = 2
console.log(addTenAdnDouble(inputNumber))  //? Output: 24

//? CallBack Function
function greetUser(name, c){
    console.log(`Hello ${name}`)
    c();
}


function sayGoodBye(){
    console.log("Good Bye")
}

greetUser("Yaya", sayGoodBye) //? Output:Hello Yaya  || Good Bye

//? Big Freeze
//! Using object.freeze():
const myVar = 3
// myVar = 4
// console.log(myVar)  //? Output: Error TypeError: Assignment to constant variable.

// const myArray = [1, 2, 3, 4]
// myArray.push(300)
// console.log(myArray)   //? Output: [ 1, 2, 3, 4, 300 ]

// const myArray = Object.freeze([1, 2, 3, 4])
// myArray.push(300)
// console.log(myArray)   //? Output: Error TypeError: Cannot add property 4, object is not extensible

const myNewUser = Object.freeze([
    {
        name: "John Doe",
        age: 27,
        email: "john@doe.com"
    },
    {
        name: "Yaya Doe",
        age: 27,
        email: "yaya@doe.com"
    },
    {
        name: "Alice Doe",
        age: 30,
        email: "alice@doe.com"
    }

])

//? .map()
const array = [1,2,3]
const newArray1 = array.map(el => el+ 1)
console.log(newArray1)   //? Output: [2,3,4]

//? .filter()
const filterUser = myNewUser.filter(user => user.age === 27)
console.log(filterUser)