class Car {
    constructor(brand, model, year, miles =0){
        this.brand = brand;  //* initialize the brand attribute
        this.model = model;  //* initialize the model attribute
        this.year = year;    //* initialize the year attribute
        this.miles = miles;      //* initialize the year attribute 
    }

    //! Method
    accelerate(){
        this.miles = this.miles +10;
        console.log(`${this.brand} ${this.model} accelerated.\nCurrent miles is : ${this.miles} km`);
    }

    displayInfo(){
        console.log(`Car Info: Brand: ${this.brand} Model: ${this.model} Year: ${this.year} and Miles: ${this.miles} km`)
    }

}

//! Creating object or instance of this class Car:
const myCar1 = new Car("Toyota", "Corolla", 2020)
myCar1.displayInfo()
myCar1.accelerate()
console.log("****************************************************************************************")
myCar1.accelerate()
console.log(myCar1.brand)  //? Output: Toyota

console.log("*********************************************************************************************")
//* Don't Repeat Yourself

//* Super Class or Parent class
class Animals{
    constructor(name){
        this.name = name; //* Initilize the name
    }

    speak(){
        console.log(`${this.name} make a sound`)
    }
}

//* Child Class or Subclass
class Cat extends Animals {
    constructor(name, age, breed){
        //* We need to define the common properties for the parent and child
        super(name); 
        this.age = age;
        this.breed = breed;
    }
    speak(){
        const message = super.speak();
        console.log(message);
        console.log(`😾 ${this.name} with ${this.age} years old and ${this.breed} make a sound: meow`)
    }
}

//* Create a new Cat Object
const mycat = new Cat("Katous", 1, "Tunisian White")
mycat.speak()